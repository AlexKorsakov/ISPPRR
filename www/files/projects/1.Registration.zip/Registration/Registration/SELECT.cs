﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public enum FormOperations
    {
        SHOW = 1,
        SELECT = 2
    } 
    public partial class SELECT : Form
    {
        int accepted;
        public DataGridViewRow row = null;
        FormOperations operation;

        public SELECT(FormOperations fo, String header, DataTable dt, String[] columnHeaders = null, int[] falsevisible = null, int o = -1)
        {
            
            InitializeComponent();
            operation = fo;
            this.Text = header;
            dataGridView1.DataSource = dt;
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
                dataGridView1.Columns[i].HeaderText = columnHeaders[i];
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            foreach (int item in falsevisible)
                dataGridView1.Columns[item].Visible = false;
            accepted = o;
            

            
        }

        private void acceptReg(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows[0].Cells[4].Value.ToString() != "1")
                    if (MessageBox.Show("Принять пациента по существующей записи?", "Прием",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                        return;
                    else { }
                else
                {
                    MessageBox.Show("По данной записи пациент уже принят!");
                    return;
                }
                Class1.dataControl("update registration set flag = 1 where id = " +
                    dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                HISTORY frmHist = new HISTORY(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                frmHist.ShowDialog();
                this.Close();
            }
            catch (System.Exception) { return; }
            
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (operation == FormOperations.SELECT)
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    row = dataGridView1.SelectedRows[0];
                    this.DialogResult = System.Windows.Forms.DialogResult.OK;
                    this.Close();
                }
            if (operation == FormOperations.SHOW)
            {
                acceptReg(sender,e);
            }
        }

        //private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        //{
        //    // Если по строке щелкнули ПКМ - выбираем её
        //    if (e.Button == MouseButtons.Right && e.RowIndex > -1)
        //        dataGridView1[e.ColumnIndex, e.RowIndex].Selected = true;
        //    if (accepted == 1 && e.Button == MouseButtons.Right && e.RowIndex > -1)
        //    {
        //        ContextMenuStrip cms = new ContextMenuStrip();
        //        cms.Items.Add("Отметить посещение", null, new System.EventHandler(acceptReg));
        //        cms.Show(Control.MousePosition.X, Control.MousePosition.Y);
        //    }
        //}

        private void SELECT_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Вы действительно хотите удалить элемент?", "Удаление",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.No)
                return;
             if (this.Text == "Анализы" || this.Text == "Записи") 
             Class1.dataControl("delete from registration where id = " +
                 dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                      else   
             Class1.dataControl("delete from history where id = " +
                dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

             
        }

        private void SELECT_Load(object sender, EventArgs e)
        {
            if (this.Text == "Записи")
                отчетToolStripMenuItem.Visible = true;
            else 
                отчетToolStripMenuItem.Visible = false;
            if (this.Text == "Врачи" || this.Text == "Пациенты")
                button1.Visible = false;
            else
                button1.Visible = true;

         
            
        }

    
        private void талонНаПриемToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

        }

        private void фильтрToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Filtration frmFil = new Filtration(dataGridView1);
            frmFil.Owner = this;
            DialogResult res = frmFil.ShowDialog();
            if (res == DialogResult.OK)
                фильтрToolStripMenuItem.Checked = true;
            else
                фильтрToolStripMenuItem.Checked = false;
        }

        private void очиститьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SELECT_Load(this, EventArgs.Empty);
            фильтрToolStripMenuItem.Checked = false;
        }

        private void талонНаПриемToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                Talon t = new Talon(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                t.ShowDialog();
            }
            catch (System.Exception) { return; }
        }

    
       

      
   
     }
}
