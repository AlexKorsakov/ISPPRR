﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class RASPISANIE : Form
    {
        public RASPISANIE()
        {
            InitializeComponent();
        }
        String id_doc = "";
        private void RASPISANIE_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataSet1TableAdapters.DOCTORS_INFOTableAdapter docView =
                new dataSet1TableAdapters.DOCTORS_INFOTableAdapter();
             SELECT frm = new SELECT(FormOperations.SELECT, "Врачи",
                docView.GetData(), 
                new String[] { "ИД", "Фамилия", "Имя", "Отчество","Участок", 
                         "Должность", "Отделение"},
                    new int[] {0});

            if (frm.ShowDialog() == DialogResult.OK)
            {
                id_doc = frm.row.Cells[0].Value.ToString();
                textBox1.Text = frm.row.Cells[1].Value.ToString() + " " +
                    frm.row.Cells[2].Value.ToString() + " " +
                    frm.row.Cells[3].Value.ToString();
            }
        }

                      
        private void insertIntoTimetable(String id_d, String day, DateTime beg, DateTime end)
        {
            Class1.dataControl("insert into time_doc (id_doct, week_day, time_b, time_e) " +
                "values (" + id_d + ", " + day + ", '" + beg.ToString("HH:mm:ss") +
                "', '" + end.ToString("HH:mm:ss") + "')");
        }

     
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            Class1.dataControl("delete from time_doc where id_doct = " + id_doc);
            if (checkBox1.Checked)
                 insertIntoTimetable(id_doc,"1", dateTimePicker1.Value, dateTimePicker2.Value);
            if (checkBox2.Checked)
                insertIntoTimetable(id_doc, "2", dateTimePicker3.Value, dateTimePicker4.Value);
            if (checkBox3.Checked)
                insertIntoTimetable(id_doc, "3", dateTimePicker5.Value, dateTimePicker6.Value);
            if (checkBox4.Checked)
                insertIntoTimetable(id_doc, "4", dateTimePicker7.Value, dateTimePicker8.Value);
            if (checkBox5.Checked)
                insertIntoTimetable(id_doc, "5", dateTimePicker9.Value, dateTimePicker10.Value);
            if (checkBox6.Checked)
                insertIntoTimetable(id_doc, "6", dateTimePicker11.Value, dateTimePicker12.Value);
           
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                dateTimePicker1.Enabled = true;
                dateTimePicker2.Enabled = true;
            }
            else
            {
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                dateTimePicker2.Enabled = true;
                dateTimePicker3.Enabled = true;
            }
            else
            {
                dateTimePicker2.Enabled = false;
                dateTimePicker3.Enabled = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                dateTimePicker4.Enabled = true;
                dateTimePicker5.Enabled = true;
            }
            else
            {
                dateTimePicker4.Enabled = false;
                dateTimePicker5.Enabled = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                dateTimePicker6.Enabled = true;
                dateTimePicker7.Enabled = true;
            }
            else
            {
                dateTimePicker6.Enabled = false;
                dateTimePicker7.Enabled = false;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                dateTimePicker8.Enabled = true;
                dateTimePicker9.Enabled = true;
            }
            else
            {
                dateTimePicker8.Enabled = false;
                dateTimePicker9.Enabled = false;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
            {
                dateTimePicker10.Enabled = true;
                dateTimePicker11.Enabled = true;
            }
            else
            {
                dateTimePicker10.Enabled = false;
                dateTimePicker11.Enabled = false;
            }
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            String val = Class1.getValue("select* from time_doc where id_doct = " + id_doc);
            if (val != null && val != "")
            {
                DialogResult res = MessageBox.Show("Для данного врача имеется расписание. Имеющиеся записи будут удалены. Продолжить?",
                    "Расписание имеется", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.No)
                {
                    id_doc = "-1";
                    textBox1.Text = "";
                }
            }
        }
    }

}
