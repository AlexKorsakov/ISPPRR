﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class PrintRasp : Form
    {
        public PrintRasp()
        {
            InitializeComponent();
        }
        
        private void PrintRasp_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.PRINT_RASP". При необходимости она может быть перемещена или удалена.
            this.PRINT_RASPTableAdapter.Fill(this.dataSet1.PRINT_RASP);
            DataTable dt = Class1.getData("select doctors.last_name || ' ' || doctors.first_name || ' ' || doctors.middle_name, " +
               "time_doc.week_day, time_doc.time_b, time_doc.time_e " +
               "from time_doc join doctors on doctors.id = time_doc.id_doct order by time_doc.id");
             ReportDataSource rprtDTSource = new ReportDataSource(dt.TableName, dt);
            this.reportViewer1.LocalReport.DataSources.Add(rprtDTSource);
            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
