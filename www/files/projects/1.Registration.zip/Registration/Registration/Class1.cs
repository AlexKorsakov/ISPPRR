﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FirebirdSql.Data.FirebirdClient;
using System.Windows.Forms;
using System.Data;

namespace Registration
{
    class Class1
    {

       static string cs = Properties.Settings.Default.ConnectionString;

      public static void dataControl(string command)
        {
            try
            {
                FbConnection connect = new FbConnection(cs);
                connect.Open();
                FbTransaction Trans = connect.BeginTransaction();
                FbCommand fbcom = new FbCommand(command, connect, Trans);
                fbcom.ExecuteNonQuery();
                fbcom.Transaction.Commit();
                connect.Close();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

      public static void insertData(string command)
      {
         try
          {
              FbConnection connect = new FbConnection(cs);
              connect.Open();
              FbCommand fbcom = new FbCommand("EXECUTE PROCEDURE GET_ID (@id_dise,@description,@result,@datetime)", connect);
              fbcom.Parameters.Add("@id_dise", FbDbType.Integer);
              fbcom.Parameters.Add("@description", FbDbType.VarChar);
              fbcom.Parameters.Add("@result", FbDbType.VarChar);
              fbcom.Parameters.Add("@datetime", FbDbType.Integer);

          }
         catch (Exception ex)
         {
             MessageBox.Show(ex.ToString());
         }
      }

        public static String getValue(string command)
          {
              String res = "";
              try
              {
                  FbConnection connect = new FbConnection(cs);
                  connect.Open();

                  FbCommand selectCommand = new FbCommand(command, connect);
                  FbDataReader rd = selectCommand.ExecuteReader();
                      while (rd.Read())
                      {
                          res = rd.GetString(0);
                      }
                  connect.Close();
                  return res;
                                }
              catch (Exception ex)
              {
                  MessageBox.Show(ex.ToString());
                  return null;
              }
          }

        public static DataTable getData(string command)
        {
            try
            {
                FbDataAdapter DA = new FbDataAdapter(command, cs);
                DataTable DT = new DataTable();
                DA.Fill(DT);

                return DT;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return null;
            }
        }

    }
}
