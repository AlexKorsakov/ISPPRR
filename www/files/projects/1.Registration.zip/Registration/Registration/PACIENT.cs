﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class PACIENT : Form
    {
        String ID;
        dataSet1TableAdapters.UCHASTOKTableAdapter uchTable = new dataSet1TableAdapters.UCHASTOKTableAdapter();
        public PACIENT(String id = "-1")
        {
            InitializeComponent();
            ID = id;
            comboBox1.DataSource = uchTable.GetData();
            comboBox1.DisplayMember = "NAME";
            comboBox1.ValueMember = "NUMBER";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
                if (ID == "-1")
                {
                    Class1.dataControl("insert into pacients " +
                        "(first_name, middle_name, last_name, region, city, " +
                        "birthday, sex, adress, polis, number) " +
                        "values ('" +
                        textBox2.Text + "', '" +
                        textBox3.Text + "', '" +
                        textBox1.Text + "', '" +
                        textBox4.Text + "', '" +
                        textBox5.Text + "', '" +
                        dateTimePicker1.Value.ToString().Substring(0, 10) + "', '" +
                        (radioButton1.Checked ? "М" : "Ж") + "', '" +
                        textBox6.Text + "', '" +
                        textBox8.Text + "', '" +
                        comboBox1.SelectedValue + "') ");

                }
                else
                {
                    Class1.dataControl("update pacients set " +
                         "first_name = '" + textBox2.Text +
                        "', middle_name = '" + textBox3.Text +
                        "', last_name = '" + textBox1.Text +
                        "', region = '" + textBox4.Text +
                        "', city = '" + textBox5.Text +
                        "', adress = '" + textBox6.Text +
                        "', birthday = '" + dateTimePicker1.Value.ToString().Substring(0, 10) +
                        "', Sex = '" + (radioButton1.Checked ? "М" : "Ж") +
                        "', polis = '" + textBox8.Text +
                        "', number = '" + comboBox1.SelectedValue +
                        "' where id = " + ID);
                }



                DialogResult res = MessageBox.Show("Применить?", "Редактирование",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.No)
                    return;

                this.Close();
        
            
                       
        }


        private void PACIENT_Load(object sender, EventArgs e)
        {
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.UCHASTOK". При необходимости она может быть перемещена или удалена.
            this.uCHASTOKTableAdapter.Fill(this.dataSet1.UCHASTOK);

        }
    }
}
