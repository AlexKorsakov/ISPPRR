﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class Filtration : Form
    {
        TextBox[] textBoxes;
        CheckBox[] checkBoxes;
        DataGridView dataGridView;
        public Filtration(DataGridView dgv)
        {
            InitializeComponent();
            DataGridViewColumnCollection cols = dgv.Columns;
            dataGridView = dgv;
            textBoxes = new TextBox[cols.Count];
            checkBoxes = new CheckBox[cols.Count];
            int i = 0;
            // Проходим по всем колонкам - добавляем тексбоксы для фильтрации
            // надписи и чекбоксы для выбора активных текстбоксов
            foreach (DataGridViewColumn item in cols)
            {
               
                Label label = new Label();
                int loc = 10 + 60 * i;
                label.Name = "label" + i;
                label.Text = item.HeaderText + ":";
                label.Location = new Point(10, loc);

               

                TextBox textBox = new TextBox();
                textBox.Size = new Size(175, 20);
                textBox.Name = "textBox" + i;
                textBox.Location = new Point(10, loc + 25);
                textBox.Enabled = false;
                textBox.Tag = i;
                textBoxes[i] = textBox;

                CheckBox checkBox = new CheckBox();
                checkBox.Name = "checkBox" + i;
                checkBox.Location = new Point(190, loc + 25);
                checkBox.Text = "";
                checkBox.Tag = i;
                checkBoxes[i] = checkBox;
                checkBox.Click += new System.EventHandler(this.checkedChanged);

                if (label.Text == "ID:" || label.Text == "ИД:")
                {
                    label.Visible = false;
                    textBox.Visible = false;
                    checkBox.Visible = false;
                }

                i++;
                this.Controls.Add(label);
                this.Controls.Add(textBox);
                this.Controls.Add(checkBox);
            }
            // Располагаем завершающие кнопки в конце
            button1.Location = new Point(button1.Location.X,
                10 + 60 * i);

            // Вычисляем размер формы
            int Y = i * 60 + 80;
            this.Size = new Size(330, Y > 500 ? 500 : Y);
        }

        private void checkedChanged(object sender, EventArgs e)
        {
            CheckBox ch = (CheckBox)sender;
            textBoxes[Convert.ToInt32(ch.Tag)].Enabled = ch.Checked;
        }

      
        private void Filtration_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (CheckBox ch in checkBoxes)
            {
                if (!ch.Checked)
                    continue;
                int i = Convert.ToInt32(ch.Tag);
                List<DataGridViewRow> remRows = new List<DataGridViewRow>();

                foreach (DataGridViewRow row in dataGridView.Rows)
                {
                    if (row.Cells[i].Value == null)
                        break;
                    if (!row.Cells[i].Value.ToString().
                        Contains(textBoxes[i].Text))
                        remRows.Add(row);
                }
                foreach (DataGridViewRow row in remRows)
                    dataGridView.Rows.Remove(row);
            }
            this.Close();
        }
    }
}
