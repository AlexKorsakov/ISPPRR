﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class KARTA : Form
    {
        String id_pac;
        public KARTA(String id)
        {
            InitializeComponent();
            id_pac = id;
        }

        private void KARTA_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.PRINT_KARTA". При необходимости она может быть перемещена или удалена.
            this.PRINT_KARTATableAdapter.Fill(this.dataSet1.PRINT_KARTA, Convert.ToInt32 (id_pac));

            this.reportViewer1.RefreshReport();
        }
    }
}
