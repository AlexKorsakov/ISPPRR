﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class RASPISANIE_2 : Form
    {
        public RASPISANIE_2()
        {
            InitializeComponent();
        }

        private void RASPISANIE_2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.TIME_DOC". При необходимости она может быть перемещена или удалена.
          //  this.tIME_DOCTableAdapter.Fill(this.dataSet1.TIME_DOC);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.DOCTORS". При необходимости она может быть перемещена или удалена.
           // this.dOCTORSTableAdapter.Fill(this.dataSet1.DOCTORS);


            DataTable dt = Class1.getData("select doctors.last_name || ' ' || doctors.first_name || ' ' || doctors.middle_name, " +
                "time_doc.week_day, time_doc.time_b, time_doc.time_e " +
                "from time_doc join doctors on doctors.id = time_doc.id_doct order by time_doc.id");
          
            dataGridView1.Rows.Add();
            //MessageBox.Show(dataGridView1.RowCount.ToString());
            //dataGridView1.RowCount = 1;
            String old = dt.Rows[0][0].ToString();
            dataGridView1.Rows[0].Cells[0].Value = old;
        
            foreach (DataRow row in dt.Rows)
            {
                 if (old != row[0].ToString())
             {
      
                         dataGridView1.Rows.Add();
                         dataGridView1.Rows[dataGridView1.RowCount - 2].Cells[0].Value =
                         row[0].ToString();
                         old = row[0].ToString();
             }
          
            dataGridView1.Rows[dataGridView1.RowCount-2].Cells[Convert.ToInt32(row[1])].Value =
                row[2].ToString() + " - " + row[3].ToString();
           
       
           }

                
            }

        private void печатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintRasp pr = new PrintRasp();
            pr.Show();
        }

           
        }
    }

    

