﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class CONTROL : Form
    {
        public CONTROL(String header)
        {
            InitializeComponent();
            this.Text = header;
        }

        private void setColumnsHeaders()
        {
            if (this.Text == "Врачи")
            {
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[1].HeaderText = "Фамилия";
                dataGridView1.Columns[2].HeaderText = "Имя";
                dataGridView1.Columns[3].HeaderText = "Отчество";
                dataGridView1.Columns[4].HeaderText = "Должность";
                dataGridView1.Columns[5].HeaderText = "Отделение";
                dataGridView1.Columns[6].HeaderText = "Участок";

            }
            else if (this.Text == "Кабинеты")
            {
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                dataGridView1.Columns[0].HeaderText = "Номер кабинета";
                dataGridView1.Columns[1].HeaderText = "Название кабинета";
                dataGridView1.Columns[2].HeaderText = "Телефон";
                dataGridView1.Columns[3].HeaderText = "Отделение";
                dataGridView1.Columns[4].HeaderText = "Владелец";
            }
           
        }

      
        private void button2_Click_1(object sender, EventArgs e)
        {
            try
            {
                int selectedRow = dataGridView1.SelectedRows[0].Index;
                switch (this.Text)
                {
                    case "Врачи":
                        DOCTORS addDocFrm = new DOCTORS(1, dataGridView1[0, selectedRow].Value.ToString());
                        addDocFrm.textBox1.Text = dataGridView1[1, selectedRow].Value.ToString();
                        addDocFrm.textBox2.Text = dataGridView1[2, selectedRow].Value.ToString();
                        addDocFrm.textBox3.Text = dataGridView1[3, selectedRow].Value.ToString();
                        addDocFrm.comboBox1.Text = dataGridView1[4, selectedRow].Value.ToString();
                        addDocFrm.comboBox2.Text = dataGridView1[5, selectedRow].Value.ToString();
                        addDocFrm.comboBox3.Text = dataGridView1[6, selectedRow].Value.ToString();
                        addDocFrm.Show();
                        break;
                    case "Кабинеты":
                        CABINET addCabFrm = new CABINET(1);
                        addCabFrm.textBox1.Text = dataGridView1[1, selectedRow].Value.ToString();
                        addCabFrm.textBox2.Text = dataGridView1[2, selectedRow].Value.ToString();
                        addCabFrm.comboBox1.Text = dataGridView1[3, selectedRow].Value.ToString();
                        addCabFrm.comboBox2.Text = dataGridView1[4, selectedRow].Value.ToString();
                        addCabFrm.textBox3.Text = dataGridView1[0, selectedRow].Value.ToString();
                        addCabFrm.Show();
                        break;

                }
                CONTROL_Load(this, e);
            }
            catch (System.Exception) { return; }
        }

        void operationDelete(String query)
        {
            DialogResult res = MessageBox.Show("Вы действительно хотите удалить элемент?", "Удаление",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.No)
                return;

            Class1.dataControl(query);
            CONTROL_Load(this, EventArgs.Empty);
        }

        private void CONTROL_Load(object sender, EventArgs e)
        {
            try
            {
                if (this.Text == "Врачи")
                {
                    dataSet1TableAdapters.DOCTORS_INFOTableAdapter docView =
                        new dataSet1TableAdapters.DOCTORS_INFOTableAdapter();
                    dataGridView1.DataSource = docView.GetData();
                }
                else if (this.Text == "Кабинеты")
                {
                    dataSet1TableAdapters.CABINET_INFOTableAdapter cabView =
                       new dataSet1TableAdapters.CABINET_INFOTableAdapter();
                    dataGridView1.DataSource = cabView.GetData();
                }

                setColumnsHeaders();
            }
            catch (System.Exception) { return; }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            switch (this.Text)
            {
                case "Врачи":
                    DataTable dtCab = Class1.getData("select * from cabinets where id_d = " +
                       dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                    if (dtCab.Rows.Count > 0)
                    {
                        MessageBox.Show("За данным врачем закреплены кабинеты." +
                            " Пожалуйста, измените их владельца, затем повторите удаление.", "Внимание!",
                             MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                         operationDelete("delete from DOCTORS where ID = " +
                        dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                    break;
                    case "Кабинеты":
                    
                        operationDelete("delete from CABINETS where NUMBER = " +
                            dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                        break;
          }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            switch (this.Text)
            {
                case "Врачи":
                    DOCTORS addDocFrm = new DOCTORS();
                    addDocFrm.ShowDialog();
                    break;
                 case "Кабинеты":
                     CABINET addCabFrm = new CABINET();
                     addCabFrm.ShowDialog();
                     break;
                            
            }
            CONTROL_Load(this, e);
        }

        private void фильтрToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CONTROL_Load(this, EventArgs.Empty);
            Filtration frmFil = new Filtration(dataGridView1);
            frmFil.Owner = this;
            DialogResult res = frmFil.ShowDialog();
            if (res == DialogResult.OK)
                фильтрToolStripMenuItem.Checked = true;
            else
                фильтрToolStripMenuItem.Checked = false;
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CONTROL_Load(this, EventArgs.Empty);
            фильтрToolStripMenuItem.Checked = false;
        }

        private void textBox1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox1.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
            }
        }

        

       
        }
    }

