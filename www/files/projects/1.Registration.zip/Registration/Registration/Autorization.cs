﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;

namespace Registration
{
    public partial class Autorization : Form
    {
        //public string UserID = "";
        //public string Password = "";
        //public string Role = "";

        public Autorization()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string UserID = textBox1.Text;
            string Password = textBox2.Text;
         

            Properties.Settings.Default["ConnectionString"] = "character set=WIN1251;data source=localhost;" +
                "initial catalog=" + Path.Combine(Environment.CurrentDirectory, "H:\\ibexpert\\REGISTRATION.FDB;") +
                "user id=" + UserID + ";password=" + Password;                
            try
            {
                FbConnection con = new FbConnection(Properties.Settings.Default.ConnectionString);
                con.Open();
                this.DialogResult = DialogResult.OK;
                con.Close();
                this.Close();
            }
            catch
            {
                MessageBox.Show("Неверное имя пользователя или пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Autorization_Load(object sender, EventArgs e)
        {

        }
    }
}
