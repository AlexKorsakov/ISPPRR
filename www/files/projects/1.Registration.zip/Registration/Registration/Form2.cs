﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class Form2 : Form
    {
        public Form2(String header)
        {
            InitializeComponent();
            this.Text = header;
            switch (header)
            {
                case "Отделения":
                    table = "DEPARTMENT";
                    break;
                case "Должности":
                    table = "POSITIONS";
                    break;
                case "Анализы":
                    table = "DES_ANALYZES";
                    break;
                case "Болезни":
                    table = "DISEASE";
                    break;
            }
        }
        dataSet1TableAdapters.DEPARTMENTTableAdapter dep = new dataSet1TableAdapters.DEPARTMENTTableAdapter();
        dataSet1TableAdapters.POSITIONSTableAdapter post = new dataSet1TableAdapters.POSITIONSTableAdapter();
        dataSet1TableAdapters.DES_ANALYZESTableAdapter analiz = new dataSet1TableAdapters.DES_ANALYZESTableAdapter();
        dataSet1TableAdapters.DISEASETableAdapter des = new dataSet1TableAdapters.DISEASETableAdapter();

        string table;
        private void Form2_Load(object sender, EventArgs e)
        {
            if (this.Text == "Отделения")
            {
                listBox1.DataSource = dep.GetData();
                listBox1.DisplayMember = "NAME";
                listBox1.ValueMember = "ID";
                listBox2.DataSource = dep.GetData();
                listBox2.DisplayMember = "Phone";
                listBox2.ValueMember = "ID";
            
            }
            else if (this.Text == "Должности")
            {
                listBox1.DataSource = post.GetData();
                listBox1.DisplayMember = "POST";
                listBox1.ValueMember = "ID";
            }
            else if (this.Text == "Анализы")
            {
                listBox1.DataSource = analiz.GetData();
                listBox1.DisplayMember = "NAME";
                listBox1.ValueMember = "ID";
            }
            else if (this.Text == "Болезни")
            {
                listBox1.DataSource = des.GetData();
                listBox1.DisplayMember = "NAME";
                listBox1.ValueMember = "ID";
           }
        }
        void operationInsert(String table)
        {
            Insert addFrm = new Insert(table);
            addFrm.ShowDialog();
            Form2_Load(this, EventArgs.Empty);
        }

        void operationUpdate(String table, String name, String id)
        {
            Insert addFrm = new Insert(table, name, id);
            addFrm.ShowDialog();
            Form2_Load(this, EventArgs.Empty);
        }

        void operationDelete(String query)
        {
            DialogResult res = MessageBox.Show("Вы действительно хотите удалить элемент?", "Удаление",
               MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.No)
                return;

            Class1.dataControl(query);
            Form2_Load(this, EventArgs.Empty);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            operationInsert(table);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            switch (this.Text)
            {
                case "Отделения":
                    operationUpdate("DEPARTMENT",
                        dep.GetData().
                        FindByID(Convert.ToInt32(listBox1.SelectedValue)).NAME,
                        listBox1.SelectedValue.ToString());
                    break;
                case "Должности":
                    operationUpdate("POSITIONS",
                        post.GetData().
                        FindByID(Convert.ToInt32(listBox1.SelectedValue)).POST,
                        listBox1.SelectedValue.ToString());
                    break;
                case "Анализы":
                    operationUpdate("DES_ANALYZES",
                        analiz.GetData().
                        FindByID(Convert.ToInt32(listBox1.SelectedValue)).NAME,
                        listBox1.SelectedValue.ToString());
                    break;
                case "Болезни":
                    operationUpdate("DISEASE",
                        des.GetData().
                        FindByID(Convert.ToInt32(listBox1.SelectedValue)).NAME,
                        listBox1.SelectedValue.ToString());
                    break;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            operationDelete("delete from " + table + " where ID = " +
                listBox1.SelectedValue.ToString());

        }

    }
}
