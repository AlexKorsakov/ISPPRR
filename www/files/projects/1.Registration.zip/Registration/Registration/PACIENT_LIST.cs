﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class PACIENT_LIST : Form
    {
        public PACIENT_LIST()
        {
            InitializeComponent();

        }

        private void PACIENT_LIST_Load(object sender, EventArgs e)
        {

            dataSet1TableAdapters.PACIENTS_INFOTableAdapter pacTable =
                new dataSet1TableAdapters.PACIENTS_INFOTableAdapter();
            dataGridView1.DataSource = pacTable.GetData();
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].HeaderText = "Фамилия";
            dataGridView1.Columns[2].HeaderText = "Имя";
            dataGridView1.Columns[3].HeaderText = "Отчество";
            dataGridView1.Columns[4].HeaderText = "Регион";
            dataGridView1.Columns[5].HeaderText = "Город";
            dataGridView1.Columns[6].HeaderText = "День рождения";
            dataGridView1.Columns[7].HeaderText = "Пол";
            dataGridView1.Columns[8].HeaderText = "Адрес";
            dataGridView1.Columns[9].HeaderText = "Полис";
            dataGridView1.Columns[10].HeaderText = "Участок";

        }

        //private void dataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        //{
        //    // Если по строке щелкнули ПКМ - выбираем её
        //    if (e.Button == MouseButtons.Right && e.RowIndex > -1)
        //        dataGridView1[e.ColumnIndex, e.RowIndex].Selected = true;
        //}


        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Вы действительно хотите удалить элемент?", "Удаление",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.No)
                return;
            try
            {
                Class1.dataControl("delete from pacients where id = " +
                     dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

                PACIENT_LIST_Load(this, EventArgs.Empty);
            }
            catch (System.Exception) { return; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                PACIENT frm = new PACIENT(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                frm.textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                frm.textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                frm.textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                frm.textBox4.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                frm.textBox5.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                frm.textBox6.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
                frm.dateTimePicker1.Value = DateTime.Parse(dataGridView1.SelectedRows[0].Cells[6].Value.ToString());
                frm.radioButton1.Checked = dataGridView1.SelectedRows[0].Cells[7].Value.ToString() == "М" ? true : false;
                frm.radioButton2.Checked = dataGridView1.SelectedRows[0].Cells[7].Value.ToString() == "Ж" ? true : false;
                frm.textBox8.Text = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
                frm.comboBox1.Text = dataGridView1.SelectedRows[0].Cells[10].Value.ToString();
                frm.ShowDialog();
                PACIENT_LIST_Load(this, EventArgs.Empty);
            }
            catch (System.Exception) { return; }
        }

        private void историяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable histView = Class1.getData("select history.id, registration.date_reg, doctors.last_name|| ' ' || doctors.first_name || ' ' || doctors.middle_name, registration.flag," +
                    "history.datetime, history.description, history.result from history  " +
                    "join registration on registration.id = history.id_reg  " +
                    "join doctors on doctors.id = registration.id_doctor where registration.id_pacient =  " +
                    dataGridView1.SelectedRows[0].Cells[0].Value.ToString());

                histView.Columns.Add("Диагноз");

                for (int i = 0; i < histView.Rows.Count; i++)
                {
                    histView.Rows[i][7] = Class1.getValue("select name from disease where id in " +
                        "(select id_dise from history where id = " + histView.Rows[i][0] + ")");
                }

                SELECT frmHist = new SELECT(FormOperations.SHOW,
                    "История: " + dataGridView1.SelectedRows[0].Cells[1].Value.ToString() + " " +
                    dataGridView1.SelectedRows[0].Cells[2].Value.ToString() + " " +
                    dataGridView1.SelectedRows[0].Cells[3].Value.ToString(),
                    histView, new String[] { "ИД",
                "Дата записи", "Врач", "Принято", "Дата приема", "Описание приема",
                "Направление на", "Диагноз"}, new int[] { 0 });
                frmHist.ShowDialog();
            }
            catch (System.Exception) { return; }
        }

        private void фильтрToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void фильтрToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //CONTROL_Load(this, EventArgs.Empty);
            Filtration frmFil = new Filtration(dataGridView1);
            frmFil.Owner = this;
            DialogResult res = frmFil.ShowDialog();
            if (res == DialogResult.OK)
                фильтрToolStripMenuItem.Checked = true;
            else
                фильтрToolStripMenuItem.Checked = false;
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PACIENT_LIST_Load(this, EventArgs.Empty);
            фильтрToolStripMenuItem.Checked = false;
        }

        private void анализыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Analyzes a = new Analyzes(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                a.ShowDialog();
            }
            catch (System.Exception) { return; }
        }

     

        private void button1_Click(object sender, EventArgs e)
        {
            PACIENT pac = new PACIENT();
            pac.ShowDialog();
            PACIENT_LIST_Load(this, EventArgs.Empty);
        }

       
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                dataGridView1.Rows[i].Selected = false;
                for (int j = 0; j < dataGridView1.ColumnCount; j++)
                    if (dataGridView1.Rows[i].Cells[j].Value != null)
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString().Contains(textBox1.Text))
                        {
                            dataGridView1.Rows[i].Selected = true;
                            break;
                        }
            }

        }

        private void медКартаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                KARTA k = new KARTA(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                k.ShowDialog();
            }
            catch (System.Exception) { return; }
        }

        private void направлениеНаАнализыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Print_Analiz pr = new Print_Analiz(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                pr.ShowDialog();
            }
            catch (System.Exception) { return; }
        }
    }
}