﻿namespace Registration
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.записьНаПриемToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.записатьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.всеЗаписиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пациентыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.регистрацияToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.списокПацентовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.принятьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.врачиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.списокВрачейToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.общееРасписаниеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьРасписаниеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кабинетыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.доппроцедурыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.отделенияToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.должностиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.анализыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.болезниToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.записьНаПриемToolStripMenuItem1,
            this.пациентыToolStripMenuItem1,
            this.врачиToolStripMenuItem1,
            this.доппроцедурыToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(451, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // записьНаПриемToolStripMenuItem1
            // 
            this.записьНаПриемToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.записатьToolStripMenuItem1,
            this.всеЗаписиToolStripMenuItem});
            this.записьНаПриемToolStripMenuItem1.Name = "записьНаПриемToolStripMenuItem1";
            this.записьНаПриемToolStripMenuItem1.Size = new System.Drawing.Size(113, 20);
            this.записьНаПриемToolStripMenuItem1.Text = "Запись на прием";
            // 
            // записатьToolStripMenuItem1
            // 
            this.записатьToolStripMenuItem1.Name = "записатьToolStripMenuItem1";
            this.записатьToolStripMenuItem1.Size = new System.Drawing.Size(134, 22);
            this.записатьToolStripMenuItem1.Text = "Записать";
            this.записатьToolStripMenuItem1.Click += new System.EventHandler(this.записатьToolStripMenuItem1_Click);
            // 
            // всеЗаписиToolStripMenuItem
            // 
            this.всеЗаписиToolStripMenuItem.Name = "всеЗаписиToolStripMenuItem";
            this.всеЗаписиToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.всеЗаписиToolStripMenuItem.Text = "Все записи";
            this.всеЗаписиToolStripMenuItem.Click += new System.EventHandler(this.всеЗаписиToolStripMenuItem_Click);
            // 
            // пациентыToolStripMenuItem1
            // 
            this.пациентыToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.регистрацияToolStripMenuItem1,
            this.списокПацентовToolStripMenuItem,
            this.принятьToolStripMenuItem1});
            this.пациентыToolStripMenuItem1.Name = "пациентыToolStripMenuItem1";
            this.пациентыToolStripMenuItem1.Size = new System.Drawing.Size(75, 20);
            this.пациентыToolStripMenuItem1.Text = "Пациенты";
            // 
            // регистрацияToolStripMenuItem1
            // 
            this.регистрацияToolStripMenuItem1.Name = "регистрацияToolStripMenuItem1";
            this.регистрацияToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
            this.регистрацияToolStripMenuItem1.Text = "Регистрация";
            this.регистрацияToolStripMenuItem1.Click += new System.EventHandler(this.регистрацияToolStripMenuItem1_Click);
            // 
            // списокПацентовToolStripMenuItem
            // 
            this.списокПацентовToolStripMenuItem.Name = "списокПацентовToolStripMenuItem";
            this.списокПацентовToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.списокПацентовToolStripMenuItem.Text = "Список пациентов";
            this.списокПацентовToolStripMenuItem.Click += new System.EventHandler(this.списокПацентовToolStripMenuItem_Click);
            // 
            // принятьToolStripMenuItem1
            // 
            this.принятьToolStripMenuItem1.Name = "принятьToolStripMenuItem1";
            this.принятьToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
            this.принятьToolStripMenuItem1.Text = "Принять";
            this.принятьToolStripMenuItem1.Click += new System.EventHandler(this.принятьToolStripMenuItem1_Click);
            // 
            // врачиToolStripMenuItem1
            // 
            this.врачиToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.списокВрачейToolStripMenuItem1,
            this.общееРасписаниеToolStripMenuItem1,
            this.добавитьРасписаниеToolStripMenuItem,
            this.кабинетыToolStripMenuItem1});
            this.врачиToolStripMenuItem1.Name = "врачиToolStripMenuItem1";
            this.врачиToolStripMenuItem1.Size = new System.Drawing.Size(53, 20);
            this.врачиToolStripMenuItem1.Text = "Врачи";
            // 
            // списокВрачейToolStripMenuItem1
            // 
            this.списокВрачейToolStripMenuItem1.Name = "списокВрачейToolStripMenuItem1";
            this.списокВрачейToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.списокВрачейToolStripMenuItem1.Text = "Список врачей";
            this.списокВрачейToolStripMenuItem1.Click += new System.EventHandler(this.списокВрачейToolStripMenuItem1_Click);
            // 
            // общееРасписаниеToolStripMenuItem1
            // 
            this.общееРасписаниеToolStripMenuItem1.Name = "общееРасписаниеToolStripMenuItem1";
            this.общееРасписаниеToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.общееРасписаниеToolStripMenuItem1.Text = "Общее расписание";
            this.общееРасписаниеToolStripMenuItem1.Click += new System.EventHandler(this.общееРасписаниеToolStripMenuItem1_Click);
            // 
            // добавитьРасписаниеToolStripMenuItem
            // 
            this.добавитьРасписаниеToolStripMenuItem.Name = "добавитьРасписаниеToolStripMenuItem";
            this.добавитьРасписаниеToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.добавитьРасписаниеToolStripMenuItem.Text = "Добавить расписание";
            this.добавитьРасписаниеToolStripMenuItem.Click += new System.EventHandler(this.добавитьРасписаниеToolStripMenuItem_Click);
            // 
            // кабинетыToolStripMenuItem1
            // 
            this.кабинетыToolStripMenuItem1.Name = "кабинетыToolStripMenuItem1";
            this.кабинетыToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.кабинетыToolStripMenuItem1.Text = "Кабинеты";
            this.кабинетыToolStripMenuItem1.Click += new System.EventHandler(this.кабинетыToolStripMenuItem1_Click);
            // 
            // доппроцедурыToolStripMenuItem1
            // 
            this.доппроцедурыToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отделенияToolStripMenuItem1,
            this.должностиToolStripMenuItem1,
            this.анализыToolStripMenuItem1,
            this.болезниToolStripMenuItem1});
            this.доппроцедурыToolStripMenuItem1.Name = "доппроцедурыToolStripMenuItem1";
            this.доппроцедурыToolStripMenuItem1.Size = new System.Drawing.Size(106, 20);
            this.доппроцедурыToolStripMenuItem1.Text = "Доп.процедуры";
            this.доппроцедурыToolStripMenuItem1.Click += new System.EventHandler(this.доппроцедурыToolStripMenuItem1_Click);
            // 
            // отделенияToolStripMenuItem1
            // 
            this.отделенияToolStripMenuItem1.Name = "отделенияToolStripMenuItem1";
            this.отделенияToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.отделенияToolStripMenuItem1.Text = "Отделения";
            this.отделенияToolStripMenuItem1.Click += new System.EventHandler(this.отделенияToolStripMenuItem1_Click);
            // 
            // должностиToolStripMenuItem1
            // 
            this.должностиToolStripMenuItem1.Name = "должностиToolStripMenuItem1";
            this.должностиToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.должностиToolStripMenuItem1.Text = "Должности";
            this.должностиToolStripMenuItem1.Click += new System.EventHandler(this.должностиToolStripMenuItem1_Click);
            // 
            // анализыToolStripMenuItem1
            // 
            this.анализыToolStripMenuItem1.Name = "анализыToolStripMenuItem1";
            this.анализыToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.анализыToolStripMenuItem1.Text = "Анализы";
            this.анализыToolStripMenuItem1.Click += new System.EventHandler(this.анализыToolStripMenuItem1_Click);
            // 
            // болезниToolStripMenuItem1
            // 
            this.болезниToolStripMenuItem1.Name = "болезниToolStripMenuItem1";
            this.болезниToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.болезниToolStripMenuItem1.Text = "Болезни";
            this.болезниToolStripMenuItem1.Click += new System.EventHandler(this.болезниToolStripMenuItem1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 340);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "ИС \"Регистратура\"";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem записьНаПриемToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem записатьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem пациентыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem регистрацияToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem списокПацентовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem принятьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem врачиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem списокВрачейToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem общееРасписаниеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem добавитьРасписаниеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кабинетыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem доппроцедурыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem отделенияToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem должностиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem анализыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem болезниToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem всеЗаписиToolStripMenuItem;

    }
}

