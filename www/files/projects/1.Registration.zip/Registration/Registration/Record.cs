﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Registration
{
    public partial class Record : Form
    {
        String id_doc, id_pac;
        public Record()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

       private void button1_Click_1(object sender, EventArgs e)
        {
           
            dataSet1TableAdapters.DOCTORS_INFOTableAdapter docView =
                new dataSet1TableAdapters.DOCTORS_INFOTableAdapter();
            SELECT frm = new SELECT(FormOperations.SELECT, "Врачи",
            docView.GetData(),
            new String[] { "ИД", "Фамилия", "Имя", "Отчество", 
                     "Участок", "Должность", "Отделение" },
                new int[] { 0 });
           
            if (frm.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = frm.row.Cells[1].Value.ToString() + " " +
                    frm.row.Cells[2].Value.ToString() + " " +
                    frm.row.Cells[3].Value.ToString();
                id_doc = frm.row.Cells[0].Value.ToString();
            }
        }

       private void button2_Click(object sender, EventArgs e)
       {
           dataSet1TableAdapters.PACIENTS_INFOTableAdapter pacTable =
               new dataSet1TableAdapters.PACIENTS_INFOTableAdapter();
           SELECT frm = new SELECT(FormOperations.SELECT, "Пациенты",
               pacTable.GetData(),
               new String[] { "ИД", "Имя", "Отчество", "Фамилия", "Регион", "Город",
                    "Адрес", "День рождения", "Пол",  "Полис", 
                    "Участок" }, new int[] { 0 });
           if (frm.ShowDialog() == DialogResult.OK)
           {
               textBox2.Text = frm.row.Cells[1].Value.ToString() + " " +
                   frm.row.Cells[2].Value.ToString() + " " +
                   frm.row.Cells[3].Value.ToString();
               id_pac = frm.row.Cells[0].Value.ToString();
           }
           
       }

       private void button3_Click(object sender, EventArgs e)
       {
         
           String val = Class1.getValue("select number from doctors where id = " + id_doc);
           String val2 = Class1.getValue("select number from pacients where id = " + id_pac);
        if(val!=val2)
           {
                DialogResult res = MessageBox.Show("Участок пациента и врача не соответствует!",
                    "Ошибка", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
                if (res == DialogResult.Retry)
                {
                    return;
                }

           }

           Class1.dataControl("insert into registration (id_doctor, id_pacient, date_reg) " +
        "values (" + id_doc + ", " + id_pac + ", '" +
        dateTimePicker1.Value.ToString().Substring(0, 10) + "')" );
           this.Close();
           //Talon t = new Talon();
           //t.ShowDialog();

           dataSet1TableAdapters.REG_INFOTableAdapter regView =
            new dataSet1TableAdapters.REG_INFOTableAdapter();
           SELECT frm = new SELECT(FormOperations.SHOW, "Записи",
               regView.GetData(), new String[] { "ИД", "Пациент", "Врач", "Дата записи", "Посещение" },
               new int[] { 0 });
              frm.ShowDialog();

           
       }

       private void button4_Click(object sender, EventArgs e)
       {
           this.Close();
       }

    

    }
}
