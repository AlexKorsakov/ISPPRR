﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class Analyzes : Form
    {
        String id_pac;
        public Analyzes(String id_p)
        {
            InitializeComponent();
            id_pac = id_p;
        }

        private void Analyzes_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable analyz = Class1.getData(
                  "select analyzes.id, des_analyzes.name, analyzes.date_b, analyzes.result, analyzes.date_e " +
                  "from analyzes join des_analyzes on des_analyzes.id = analyzes.id_analyz " +
                  "join history on history.id = analyzes.id_hist " +
                  "join registration on registration.id = history.id_reg " +
                  "where registration.id_pacient = " + id_pac);

                dataGridView1.DataSource = analyz;

                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[1].HeaderText = "Наименование анализа";
                dataGridView1.Columns[2].HeaderText = "Дата назначения анализа";
                dataGridView1.Columns[3].HeaderText = "Результат";
                dataGridView1.Columns[4].HeaderText = "Дата результата";
            }
            catch (System.Exception) { return; }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Вы действительно хотите удалить элемент?", "Удаление",
             MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.No)
                return;

            Class1.dataControl("delete from ANALYZES where id = " +
                dataGridView1.SelectedRows[0].Cells[0].Value);
            Analyzes_Load(this, EventArgs.Empty);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Insert frmAdd = new Insert("analyzes", "",
                    dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                frmAdd.ShowDialog();
                Analyzes_Load(this, EventArgs.Empty);
            }
            catch (System.Exception) { return; }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


    }
}
