﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class DOCTORS : Form
    {
        dataSet1TableAdapters.POSITIONSTableAdapter postsTable = new dataSet1TableAdapters.POSITIONSTableAdapter();
        dataSet1TableAdapters.DEPARTMENTTableAdapter officesTable = new dataSet1TableAdapters.DEPARTMENTTableAdapter();
        dataSet1TableAdapters.UCHASTOKTableAdapter uchTable = new dataSet1TableAdapters.UCHASTOKTableAdapter();
        int operation;
        String oldID;
        public DOCTORS(int oper = 0, String ID = "0")
        {
            InitializeComponent();
            operation = oper;
            oldID = ID;
            try
            {
                comboBox2.DataSource = officesTable.GetData();
                comboBox2.DisplayMember = "NAME";
                comboBox2.ValueMember = "ID";

                comboBox1.DataSource = postsTable.GetData();
                comboBox1.DisplayMember = "POST";
                comboBox1.ValueMember = "ID";

                comboBox3.DataSource = uchTable.GetData();
                comboBox3.DisplayMember = "NAME";
                comboBox3.ValueMember = "NUMBER";
            }
            catch (System.Exception) { return; }
        }

        private void DOCTORS_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (operation == 0)
            {
                Class1.dataControl(
                    "insert into doctors (last_name, first_name, middle_name, number, id_post, id_dep)" +
                    " values ('" + textBox1.Text + "', '" + textBox2.Text +
                    "', '" + textBox3.Text + "', '" +comboBox3.SelectedValue+ 
                    "', '"  + comboBox1.SelectedValue +
                    "', '" + comboBox2.SelectedValue + "')");
            }
            else
            {
                Class1.dataControl(
                    "update doctors set last_name = '" + textBox1.Text +
                    "', first_name = '" + textBox2.Text +
                    "', middle_name = '" + textBox3.Text +
                    "', number = '" + comboBox3.SelectedValue +
                    "', id_post = '" + comboBox1.SelectedValue +
                    "', id_dep = '" + comboBox2.SelectedValue + "' where id = " + oldID);
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
