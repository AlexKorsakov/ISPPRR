﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class HISTORY : Form
    {
        String id_registration;
        String id_diagnoz = "-1";
        String id_new_hist;
        public HISTORY(String id_reg = "-1")
        {
            InitializeComponent();
            id_registration = id_reg;
            listBox1.DisplayMember = "NAME";
            listBox1.ValueMember = "ID";
            comboBox1.DisplayMember = "NAME";
            comboBox1.ValueMember = "ID";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
               
                dataSet1TableAdapters.DES_ANALYZESTableAdapter allanalyzTable =
                    new dataSet1TableAdapters.DES_ANALYZESTableAdapter();
                comboBox1.DataSource = allanalyzTable.GetData();
            }
            else
            {
                comboBox1.DataSource = null;
                comboBox1.Items.Clear();
                listBox1.Items.Clear();
               
            }
        }

        //private void checkBox2_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (checkBox2.Checked)
        //    {
        //        textBox3.Enabled = true;
        //        button4.Enabled = true;
        //    }
        //    else
        //    {
        //        textBox3.Enabled = false;
        //        button4.Enabled = false;
        //    }
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Contains(comboBox1.SelectedItem))
            {
                MessageBox.Show("Данный элемент уже добавлен!");
                return;
            }
            listBox1.Items.Add(comboBox1.SelectedItem);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(listBox1.SelectedItem);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
              Class1.dataControl("insert into history (id_reg, " +
               "id_dise, description, datetime) values (" +
             id_registration + ", " + id_diagnoz + ", '" + textBox1.Text + "', '" +
                 DateTime.Now.ToString() + "') ");
               /* Class1.insertData("EXECUTE PROCEDURE GET_ID (@id_dise,@description,@result,@datetime) values(" +
                    id_registration + ", " + id_diagnoz + ", '" + textBox1.Text + "', '" +
                   textBox2.Text + "', '" + DateTime.Now.ToString() + "') ");*/
            else
                Class1.dataControl("insert into history (id_reg, " +
                 "description, result, datetime) values (" +
                 id_registration + ", '" + textBox1.Text + "', '" +
                 comboBox1.Text + "', '" + DateTime.Now.ToString() + "')");

            if(checkBox2.Checked)
                       id_new_hist = Class1.getValue("select id from history where id_reg = " + id_registration);
            else
                       id_new_hist = Class1.getValue("select id from history where id_reg = " + id_registration);

            if (checkBox1.Checked)
                foreach (DataRowView item in listBox1.Items)
                {
                    String id_an = item.Row.ItemArray[0].ToString();
                    Class1.dataControl
                        ("insert into analyzes (id_hist, id_analyz, date_b) values (" +
                        id_new_hist + ", " + id_an +
                        ", '" + DateTime.Now.ToString().Substring(0, 10) + "')");
                }
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataSet1TableAdapters.DISEASETableAdapter dTable = new dataSet1TableAdapters.DISEASETableAdapter();

            SELECT frm = new SELECT(FormOperations.SELECT, "Диагнозы",
                dTable.GetData(),
                new String[] { "ИД", "Наименование","Описание" },
                    new int[] { 0 });

            if (frm.ShowDialog() == DialogResult.OK)
            {
                textBox3.Text = frm.row.Cells[1].Value.ToString();
                id_diagnoz = frm.row.Cells[0].Value.ToString();
            }
        }
    }
}
