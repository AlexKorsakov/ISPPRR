﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class CABINET : Form
    {
        dataSet1TableAdapters.DEPARTMENTTableAdapter dep = new dataSet1TableAdapters.DEPARTMENTTableAdapter();
        dataSet1TableAdapters.DOCTORSTableAdapter doc = new dataSet1TableAdapters.DOCTORSTableAdapter();
        int operation;
        public CABINET(int oper = 0)
        {
            InitializeComponent();
            operation = oper;
            comboBox1.DisplayMember = "NAME";
            comboBox1.ValueMember = "ID";
            comboBox1.DataSource = dep.GetData();

            selectDOC();

            if (oper != 0)
                textBox1.ReadOnly = true;
        }

        private void selectDOC()
        {
            comboBox2.Text = "";
            comboBox2.DisplayMember = "LAST_NAME" ;
            comboBox2.ValueMember = "ID";
            comboBox2.DataSource = Class1.getData("select id, last_name from doctors where " + "id_dep = " + comboBox1.SelectedValue);
                   
                       
        }
          private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          if (operation == 0)
            {
                Class1.dataControl(
                    "insert into cabinets (name, phone, number,id_d )" +
                    " values ('" + textBox1.Text + "', '" +  textBox2.Text + "', '" + textBox3.Text +
                    "', '" + comboBox1.SelectedValue + "')");

                // История кабинетов
                String numCab = textBox3.Text;
                String idDoc = comboBox1.SelectedValue.ToString();
                String dateBeg = DateTime.Now.ToString().Substring(0, 10);
                String dateEnd = DateTime.Now.ToString().Substring(0, 10);

                Class1.dataControl("insert into history_cab (num_cab, id_doct, date_b,date_e) values (" +
                    numCab + ", " + idDoc + ", '" + dateBeg +", '"+ dateEnd + "')");
            }
            else
            {
                Class1.dataControl(
                    "update cabinets set id_d = '" + comboBox1.SelectedValue +
                     "', name = '" + textBox1.Text +
                    "', phone = '" + textBox2.Text + "' where number = " + textBox3.Text);
            }

            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            selectDOC();
        }
    }
}
