﻿namespace Registration {
    
    
    public partial class dataSet1 {
    }
}
namespace Registration {
    
    
    public partial class dataSet1 {
    }
}

namespace Registration.dataSet1TableAdapters {
    
    
    public partial class REG_INFOTableAdapter {
    }
}
