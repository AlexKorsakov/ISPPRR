﻿
using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class Talon : Form
    {
        String id_registration;
        public Talon(String id_reg)
        {
            InitializeComponent();
            id_registration = id_reg;
        }
         
         private void Talon_Load(object sender, EventArgs e)
         {
             // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.PRINT_TALON". При необходимости она может быть перемещена или удалена.
             try
             {
                 this.PRINT_TALONTableAdapter.Fill(this.dataSet1.PRINT_TALON, Convert.ToInt32(id_registration));
                 this.reportViewer1.RefreshReport();
             }
             catch (System.Exception) { return; }
//DataTable dt = GetDataTable(employee_id);
//dt.TableName = "reportTable";
//ReportDataSource rds = new ReportDataSource("reportTable", dt);
//reportViewer1.ProcessingMode = ProcessingMode.Local;
//reportViewer1.LocalReport.DataSources.Clear();
//reportViewer1.LocalReport.ReportPath = "reportTable.rdlc";
//reportViewer1.LocalReport.DataSources.Add(rds);
//reportViewer1.LocalReport.Refresh();
             //DataTable dt = Class1.getData("select pacient, doctor, date_reg from reg_info where id = " + id_registration);
             //dt.TableName = "reg_info";
             //reportViewer1.ProcessingMode = ProcessingMode.Local;
             //ReportDataSource r = new ReportDataSource("reg_info",dt);
             //reportViewer1.LocalReport.DataSources.Add(r);
             // reportViewer1.LocalReport.Refresh();

             //ReportParameter p1 = new ReportParameter("p1","Гоштаутас");
            //  reportViewer1.LocalReport.SetParameters(new ReportParameter[] { dt });

             //this.reportViewer1.RefreshReport();
             // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.REG_INFO". При необходимости она может быть перемещена или удалена.

             this.reportViewer1.RefreshReport();
         }

       
     
    }
}
