﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using FirebirdSql.Data.FirebirdClient;


namespace Registration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }



        private void Form1_Load(object sender, EventArgs e)
        {
            Autorization f2 = new Autorization();
            f2.ShowDialog();
            //FbConnectionStringBuilder sb = new FbConnectionStringBuilder(Properties.Settings.Default.ConnectionString);
            //sb.UserID = f2.UserID;
            //sb.Password = f2.Password;
            //sb.Role = f2.Role;
            //Properties.Settings.Default["ConnectionString"] = sb.ConnectionString;

        }



        private void записатьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Record newMdiChild = new Record();
            newMdiChild.MdiParent = this; // новая форма дочерняя по  
            //отношению к главной mdi-форме
            newMdiChild.Show();

        }

        private void регистрацияToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PACIENT p = new PACIENT();
            p.MdiParent = this;
            p.Show();
        }

        private void списокПацентовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PACIENT_LIST pl = new PACIENT_LIST();
            //pl.MdiParent = this;
             pl.Show();
        }

        private void принятьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            dataSet1TableAdapters.REG_INFOTableAdapter regView =
             new dataSet1TableAdapters.REG_INFOTableAdapter();
            SELECT frm = new SELECT(FormOperations.SHOW, "Прием",
                regView.GetData(), new String[] { "ИД", "Пациент", "Врач", "Дата записи", "Посещение" },
                new int[] { 0 });
             frm.Show();

        }

        private void списокВрачейToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            CONTROL frm = new CONTROL("Врачи");
            //frm.MdiParent = this;
            frm.Show();
        }

        private void общееРасписаниеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RASPISANIE_2 r = new RASPISANIE_2();
           // r.MdiParent = this;
            r.Show();
        }

        private void добавитьРасписаниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RASPISANIE rasp = new RASPISANIE();
            rasp.MdiParent = this;
            rasp.Show();
        }

        private void кабинетыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            CONTROL frm = new CONTROL("Кабинеты");
            frm.MdiParent = this;
            frm.Show();
        }

        private void отделенияToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2("Отделения");
            frm.ShowDialog();
        }

        private void должностиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2("Должности");
            frm.ShowDialog();
        }

        private void анализыToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2("Анализы");
            frm.ShowDialog();
        }

        private void болезниToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2("Болезни");
            frm.ShowDialog();
        }

        private void всеЗаписиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataSet1TableAdapters.REG_INFOTableAdapter regView =
            new dataSet1TableAdapters.REG_INFOTableAdapter();
            SELECT frm = new SELECT(FormOperations.SHOW, "Записи",
                regView.GetData(), new String[] { "ИД", "Пациент", "Врач", "Дата записи", "Посещение" },
                new int[] { 0 });
                 frm.Show();
        }

        private void доппроцедурыToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void историяДолжностейToolStripMenuItem_Click(object sender, EventArgs e)
        {
       }
    }
}
