﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registration
{
    public partial class Insert : Form
    {
        public Insert(String t, String val = "", String idVal = "")
       {
            InitializeComponent();
            table = t;
            textBoxValue.Text = val;
            value = val;
            idValue = idVal;
        }
        String table;
        String value;
        String idValue;
        private void Insert_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (table == "analyzes")
            {
                Class1.dataControl("UPDATE " + table +
                    " SET result = '" + textBoxValue.Text + "', date_e = '" +
                    DateTime.Now.ToString().Substring(0, 10) + "' where " +
                    "id = " + idValue);
                return;
            }
            String field = "name";
            if (table == "POSTS")
                field = "post";

            if (value == "")
                Class1.dataControl("INSERT into " + table +
                    " (" + field + ") values ('" + textBoxValue.Text + "')");
            else
            {
                if (value == textBoxValue.Text)
                    this.Close();

                Class1.dataControl("UPDATE " + table +
                    " SET " + field + " = '" + textBoxValue.Text + "' where " +
                    "id = " + idValue);
            }
            this.Close();
        }
    }
}
